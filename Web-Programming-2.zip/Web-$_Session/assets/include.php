<?php

session_start();

$dbPassword = "password!23";
$dbUserName = "sample";
$dbServer = "localhost";
$dbName = "sampletable";

?>